local Heart = require("defs.hearts.heart")

require("defs.hearts.foresthearts")
require("defs.hearts.swamphearts")
require("defs.hearts.tundrahearts")

return Heart