TheDebugSettings = {
	showActiveAABB = false,
	propshidden = false,
}

