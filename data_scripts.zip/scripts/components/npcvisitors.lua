local NpcVisitors = Class(function(self, inst)
	self.inst = inst
end)

return NpcVisitors
